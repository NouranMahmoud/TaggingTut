<!-- 1. Provide a general summary of the issue in the Title above -->

<!-- 2. Enter your issue details below this comment. -->

<!-- FOR BUG REPORTS -->
### Reproduction Link

<!-- fork this -->
https://jsfiddle.net/tj2Lo4z7/

## Your Environment
<!-- Include the following details: -->
* flatpickr version used:
* Browser name and version:
* OS and version:
